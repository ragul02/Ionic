import { Component, ViewChild, ElementRef } from '@angular/core';
import { NavController } from 'ionic-angular';
import { IonicPage } from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
import { Platform } from 'ionic-angular';


declare var google :any;

@IonicPage()
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  @ViewChild('map') mapElement: ElementRef;
  dis :String = '65';
  map: any;
   
  start ='' ;
  end = '';
  directionsService = new google.maps.DirectionsService;
  directionsDisplay = new google.maps.DirectionsRenderer;

  constructor(platform: Platform,public navCtrl: NavController,private geolocation: Geolocation) {
platform.ready().then(() => { 
 this.initMap();
});
  }



  // ionViewDidLoad(){
  //   this.initMap();
  // }

  initMap() {
    let locationOptions = { timeout: 20000, enableHighAccuracy: true };
    
    this.map = new google.maps.Map(this.mapElement.nativeElement, {
      zoom: 7,
      center:  navigator.geolocation.getCurrentPosition(

      (position) => {

        let options = {
          center: new google.maps.LatLng(position.coords.latitude, position.coords.longitude),
          zoom: 16,
          mapTypeId: google.maps.MapTypeId.ROADMAP
        }

        this.map = new google.maps.Map(document.getElementById("map"), options);
        let marker = new google.maps.Marker({
          map: this.map,
          animation: google.maps.Animation.DROP,
           position: this.map.getCenter()
        });
      },



      (error) => {
        console.log(error);
      }, locationOptions
    ),
  
   });

    this.directionsDisplay.setMap(this.map);


  }

  calculateAndDisplayRoute() {
console.log('navigator.geol',navigator.geolocation.watchPosition);
           console.log('inside calculateAndDisplayRoute');
    this.directionsService.route({

   origin :this.map.getCenter(), ///1.31 pm replace by below code
    // origin :   this.map.Geolocation,
      destination: this.end,

  
      travelMode: 'TRANSIT',
    }, (response, status) => {
       console.log('origin',this.start,'end==>',this.end,response);
      if (status === 'OK') {
        console.log('inisde OK');
       console.log('distance==>',response.routes[0].legs[0].distance);
      this.dis = response.routes[0].legs[0].distance.value;
      parseInt( response.routes[0].legs[0].distance.value)
       // console.log('dis==>',this,navigator.geolocation);
       if( parseInt( response.routes[0].legs[0].distance.value) <= 3000){
             window.alert('YOUR DESTINATION IS LESS THAN 1km');     
       }
        this.directionsDisplay.setDirections(response);
      } else {
        window.alert('Directions request failed due to ' + status);
      }
    });
  }

}
